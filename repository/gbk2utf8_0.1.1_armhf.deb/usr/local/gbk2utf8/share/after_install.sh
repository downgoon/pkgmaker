#!/bin/bash
ln -sf /usr/local/gbk2utf8/bin/gbk2utf8 /usr/local/bin/gbk2utf8
